package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String un="root";
		String pass="root";
		String url="jdbc:mysql://localhost:3306/sakthi";
		Scanner sc=new Scanner(System.in);
	
		
		try {
		Class.forName(driver);
		Connection conn=DriverManager.getConnection(url,un,pass);
		Statement st=conn.createStatement();
		System.out.println("Enter the Account no");
		int accno=sc.nextInt();
		String s="select * from accounts where account_no="+accno;
		ResultSet rs=st.executeQuery(s);
		if (rs.next()){
			System.out.println("Enter Pin");
			int pin=sc.nextInt();
			String ins="Select * from accounts where account_no="+accno+" and pin_no="+pin;
			ResultSet op=st.executeQuery(s);
			if(op.next()){
				ATMprocess.transaction();
			}
			else {
				System.out.println("Wrong pin");
			}
		}
		else {
			System.out.println("Enter valid account no");
		}
		
		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
